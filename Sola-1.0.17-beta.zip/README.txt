SOLA 1.0.17 — BETA
FastFlag profile manager for Roblox Player (Windows, .NET Framework 4.8)

No installer. Extract the files into one folder and run Sola.exe.

FILES
  Sola.exe            the application
  FFlags_New.hpp      bundled offset table (keep it beside the exe)
  offsets_new.hpp     struct offsets for the same header set
  LICENSE.txt         the licence you agree to by running Sola

QUICK START
  1. Extract all files together, then run Sola.exe. The title bar reads "Sola · FastFlag Studio · v1.0.17".
  2. Open Appearance & settings and select your Roblox Player folder (the ...\Versions\version-xxxx
     folder that contains RobloxPlayerBeta.exe).
  3. Load the Offense preset or import a profile, then press Apply.
  4. Revert restores the previous ClientAppSettings.json and returns every live flag to its old value.

WHAT APPLY DOES
  - Merges the profile into ClientSettings\ClientAppSettings.json for the next launch (atomic write,
    one-step byte-exact undo).
  - Mirrors the profile into %LocalAppData%\Syntax\status.json.
  - If the matching Roblox player is running, writes the values into its memory and holds them with a
    10 ms lock loop. Revert writes the captured originals back.
  - Refuses live writes and reports "Nothing was written" when the running player is not from the
    selected folder, when more than one client runs from it, or when its version-xxxx build does not
    match the offset table. The settings file is still updated in those cases only when Apply says so.

CLOSE GUARD
  Closing Sola while a player it attached to is still running shows:
    "Closing Sola will also close the attached Roblox window. Close both?"
  No leaves Sola and the player open. Yes closes Sola and only that player; any other Roblox window
  stays open. If the profile was applied and then reverted but that player still runs, Sola stays open
  and asks you to close the player first.

BETA NOTES
  - The exe is unsigned. Windows SmartScreen and some antivirus products will flag it. AVG has deleted
    earlier builds; add an exclusion for the folder before extracting if that happens.
  - Live writes go into another process's memory. A Roblox update invalidates the offsets until a table
    for the new build is available; Apply then refuses rather than writing to the wrong address.
  - Flags the client recomputes itself (for example DFIntRenderTextureTotalBudgetMB) are listed as
    client-owned and skipped.
  - Text values longer than 15 bytes reach the settings file only, never live memory.
  - Optional session receipts are off unless SOLA_RECEIPT_URL and SOLA_RECEIPT_TOKEN are set for that
    launch. With neither set, Sola sends no network receipts at all. Local usage logs live in
    %LocalAppData%\SolaFlagStudio\Logs and can be checked with:
      Sola.exe --verify-log <file.jsonl>
  - --selftest-live is compiled out of this build and exits 2.

VERIFY THE DOWNLOAD
  Get-FileHash -Algorithm SHA256 .\Sola.exe
  Expected: ED062AB6866FB68FD289F2F37205D2D69855D09EA52A68675E392195004809E2
  The exe hash changes on every rebuild, so compare it to the value above rather than to another
  download's hash. File size: 1,041,408 bytes.

REPORTING A PROBLEM
  Include the Sola.exe SHA-256 you ran, your Windows version, the Roblox version-xxxx folder, the
  RobloxPlayerBeta.exe PID involved, and the exact status or dialog text. "Could not test" is useful;
  a guess is not.
